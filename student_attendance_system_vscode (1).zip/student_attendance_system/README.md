# Student Attendance System

A simple browser-based student attendance tracker built with HTML, CSS, and JavaScript.

## Features
- Add students with a name and unique student ID
- Mark students present or absent for a selected date
- View total students, present students, absent students, and attendance rate
- Search students by name or ID
- Mark everyone present for the selected date
- Export the selected day's attendance as a CSV file
- Save demo data in browser local storage

## How to run
1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Add students and record attendance.

No installation or build step is required.

## Important limitation
This is a front-end demonstration project. Data is stored only in the current browser, so it does not sync across devices and is not suitable for official records without a secure backend and database.

## Built with
- HTML5
- CSS3
- Vanilla JavaScript

## Future improvements
- User login and roles (admin/lecturer)
- Database-backed storage
- Attendance reports by course and semester
- Secure backup and restore

## Open in Visual Studio Code
1. Extract the ZIP file.
2. Open Visual Studio Code.
3. Choose **File → Open Folder** and select the extracted `student_attendance_system` folder.
4. For easy preview, install the recommended **Live Server** extension, then right-click `index.html` and select **Open with Live Server**.

The `.vscode` folder contains workspace settings and extension recommendations. The project itself uses plain HTML, CSS, and JavaScript, so no build tools or `npm install` are required.
