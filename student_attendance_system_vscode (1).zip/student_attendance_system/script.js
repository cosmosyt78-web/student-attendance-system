const STORAGE_KEY = "student-attendance-system-v1";
const $ = (id) => document.getElementById(id);
const today = () => new Date().toLocaleDateString("en-CA");
let students = loadStudents();

function loadStudents() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch { return []; }
}
function saveStudents() { localStorage.setItem(STORAGE_KEY, JSON.stringify(students)); }
function selectedDate() { return $("attendanceDate").value || today(); }
function attendanceFor(student, date) {
  return student.attendance?.[date] || "Absent";
}
function setAttendance(studentId, status) {
  const student = students.find(s => s.id === studentId);
  if (!student) return;
  student.attendance ||= {};
  student.attendance[selectedDate()] = status;
  saveStudents();
  render();
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function render() {
  const date = selectedDate();
  const query = $("searchInput").value.trim().toLowerCase();
  const present = students.filter(s => attendanceFor(s, date) === "Present").length;
  $("totalStudents").textContent = students.length;
  $("presentCount").textContent = present;
  $("absentCount").textContent = students.length - present;
  $("attendanceRate").textContent = students.length ? Math.round(present / students.length * 100) + "%" : "0%";

  const filtered = students.filter(s => s.name.toLowerCase().includes(query) || s.id.toLowerCase().includes(query));
  $("studentTable").innerHTML = filtered.map(s => {
    const status = attendanceFor(s, date);
    return `<tr>
      <td class="student-name">${escapeHtml(s.name)}</td>
      <td class="student-id">${escapeHtml(s.id)}</td>
      <td><span class="badge ${status.toLowerCase()}">${status}</span></td>
      <td><div class="row-actions">
        <button type="button" data-action="present" data-id="${escapeHtml(s.id)}">Present</button>
        <button type="button" class="secondary" data-action="absent" data-id="${escapeHtml(s.id)}">Absent</button>
        <button type="button" class="remove" data-action="remove" data-id="${escapeHtml(s.id)}">Remove</button>
      </div></td>
    </tr>`;
  }).join("");
  $("emptyMessage").hidden = filtered.length > 0;
  $("emptyMessage").textContent = students.length ? "No matching students found." : "No students yet. Use the form above to add your first student.";
}

$("studentForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = $("studentName").value.trim();
  const id = $("studentId").value.trim();
  if (!name || !id) return;
  if (students.some(s => s.id.toLowerCase() === id.toLowerCase())) {
    alert("That student ID already exists. Please use a unique ID.");
    return;
  }
  students.push({ name, id, attendance: { [selectedDate()]: "Absent" } });
  saveStudents();
  $("studentForm").reset();
  render();
});
$("studentTable").addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const { action, id } = button.dataset;
  if (action === "present") setAttendance(id, "Present");
  else if (action === "absent") setAttendance(id, "Absent");
  else if (action === "remove" && confirm("Remove this student and their attendance records?")) {
    students = students.filter(s => s.id !== id);
    saveStudents();
    render();
  }
});
$("attendanceDate").addEventListener("change", render);
$("searchInput").addEventListener("input", render);
$("markAllPresent").addEventListener("click", () => {
  students.forEach(s => { s.attendance ||= {}; s.attendance[selectedDate()] = "Present"; });
  saveStudents();
  render();
});
$("exportCsv").addEventListener("click", () => {
  const date = selectedDate();
  const rows = [["Student Name", "Student ID", "Date", "Status"], ...students.map(s => [s.name, s.id, date, attendanceFor(s, date)])];
  const csv = rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `attendance-${date}.csv`;
  link.click();
  URL.revokeObjectURL(url);
});
$("attendanceDate").value = today();
render();
